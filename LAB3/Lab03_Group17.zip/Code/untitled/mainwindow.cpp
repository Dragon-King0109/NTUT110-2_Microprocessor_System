#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <stdio.h>
#include <stdlib.h>
#include <QTimer>
#include <unistd.h>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Mybutton1_clicked()
{
    if(ui->LED1->isChecked() == true)
    {
        ui->label->setEnabled(true);
    }
    else
    {
        ui->label->setEnabled(false);
    }
    if(ui->LED2->isChecked() == true)
    {
        ui->label_2->setEnabled(true);
    }
    else
    {
        ui->label_2->setEnabled(false);
    }
    if(ui->LED3->isChecked() == true)
    {
        ui->label_3->setEnabled(true);
    }
    else
    {
        ui->label_3->setEnabled(false);
    }
    if(ui->LED4->isChecked() == true)
    {
        ui->label_4->setEnabled(true);
    }
    else
    {
        ui->label_4->setEnabled(false);
    }
}
int Rcount=0;
QTimer *timer = new QTimer();
int count = 0;
void MainWindow::on_LED_Switching_clicked()
{
    Rcount = 0;
    count =(ui->TIme_count_text->toPlainText()).toInt();
    connect(timer,SIGNAL(timeout()),this, SLOT(switchingLED()));
    timer->start(1000);
}


void MainWindow::switchingLED(){
    if(Rcount == count*2-1){
        timer->stop();
    }
    ui->label->setEnabled(!ui->label->isEnabled());
    ui->LED1->setChecked(!ui->LED1->isChecked());
    ui->label_2->setEnabled(!ui->label_2->isEnabled());
    ui->LED2->setChecked(!ui->LED2->isChecked());
    ui->label_3->setEnabled(!ui->label_3->isEnabled());
    ui->LED3->setChecked(!ui->LED3->isChecked());
    ui->label_4->setEnabled(!ui->label_4->isEnabled());
    ui->LED4->setChecked(!ui->LED4->isChecked());
    Rcount +=1;

}

void MainWindow::on_TIme_count_text_destroyed()
{
}
